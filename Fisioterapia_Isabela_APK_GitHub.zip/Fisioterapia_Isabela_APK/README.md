# Fisioterapia Isabela — APK Android

Projeto Android que empacota o sistema HTML da Fisioterapia Domiciliar Isabela Martins em um app nativo WebView.

## O que foi preservado
- Login e sincronização Supabase
- Agenda, pacientes, evoluções e financeiro
- Consulta de CEP/endereço
- Abertura do Google Maps
- Seleção de anexos
- Download de backup/Excel para a pasta Downloads/Fisioterapia Isabela
- Abertura de anexos pelo Android
- Regra dos modais: clicar fora não fecha a janela

## Gerar APK no GitHub
Abra a aba **Actions**, escolha **Gerar APK**, execute o workflow e baixe o artefato **Fisioterapia-Isabela-APK**.
